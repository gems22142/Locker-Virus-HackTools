package com.hacktools;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class PasswordCheck {
    private Context context;
    private static final String PREFS_NAME = "PasswordPrefs";
    private static final String KEY_ATTEMPTS = "attempts";
    private static final String KEY_BUTTON_ENABLED = "button_enabled";
    private Handler handler;
    private Runnable homeButtonPressRunnable;

    public PasswordCheck(Context context) {
        this.context = context;
        this.handler = new Handler();
    }

    public void setupPasswordCheck(final View bannerView) {
        final EditText editTextPassword = bannerView.findViewById(R.id.edittext1);
        final Button buttonCheck = bannerView.findViewById(R.id.button1);
        final TextView textViewAttempts = bannerView.findViewById(R.id.textview3);

        final SharedPreferences preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        final int[] attempts = {preferences.getInt(KEY_ATTEMPTS, 5)};
        boolean buttonEnabled = preferences.getBoolean(KEY_BUTTON_ENABLED, true);

        textViewAttempts.setText("Attempts " + attempts[0]);
        buttonCheck.setEnabled(buttonEnabled);

        buttonCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputPassword = editTextPassword.getText().toString();
                if ("7930209".equals(inputPassword)) {
                    WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
                    if (windowManager != null) {
                        windowManager.removeView(bannerView);
                    }
                    stopHomeButtonPress();
                } else {
                    attempts[0]--;
                    textViewAttempts.setText("Attempts" + attempts[0]);
                    editTextPassword.setText("");

                    preferences.edit().putInt(KEY_ATTEMPTS, attempts[0]).apply();

                    if (attempts[0] <= 0) {
                        buttonCheck.setEnabled(false);
                        preferences.edit().putBoolean(KEY_BUTTON_ENABLED, false).apply();
                    }
                }
            }
        });
    }

    private void stopHomeButtonPress() {
        if (homeButtonPressRunnable != null) {
            handler.removeCallbacks(homeButtonPressRunnable);
        }
    }
}